r"""
Use this module to write your answers to the questions in the notebook.

Note: Inside the answer strings you can use Markdown format and also LaTeX
math (delimited with $$).
"""

# ==============
# Part 1 (Backprop) answers

part1_q1 = r"""
**Your answer:**



### 1. 
**A.** The Jacobian shape calculation can be summarized as follows:
$
\text{Given:} \quad 
\mat{X} \in \mathbb{R}^{N \times \text{in\_features}}, \quad 
\mat{W} \in \mathbb{R}^{\text{out\_features} \times \text{in\_features}}, \quad 
\mat{Y} \in \mathbb{R}^{N \times \text{out\_features}}
$

I. Total elements in $\mat{Y}$:
$
N \cdot \text{out\_features} = 64 \cdot 512 = 32,768
$

II. Total elements in $\mat{X}$:
$
N \cdot \text{in\_features} = 64 \cdot 1024 = 65,536
$

III. Shape of the Jacobian:
$
\frac{\partial \mat{Y}}{\partial \mat{X}} \in \mathbb{R}^{(N \cdot \text{out\_features}) \times (N \cdot \text{in\_features})} = \mathbb{R}^{32,768 \times 65,536}
$.
    
**B.** Yes, the Jacobian is sparse because most elements are zero. 
on-zero elements exist only for input features $ \mathbf{X}[i, :] $ that directly affect the output $ \mathbf{Y}[i, j] $, corresponding to the $ j $-th feature of $ \mathbf{Y} $. 
Specifically, $ \frac{\partial Y[i, j]}{\partial X[i, n]} = W[j, n] $. All other elements , $ \frac{\partial Y[i, j]}{\partial X[m, n]} = 0 $ , $( i \neq m )$ are zero, making the Jacobian block-sparse.

**C.** No, we do not need to materialize the Jacobian to calculate the downstream gradient $ \delta X = \frac{\partial L}{\partial X} $. 
Instead, the downstream gradient can be calculated efficiently using matrix multiplication, leveraging the fact that the Jacobian         $  \frac{\partial Y}{\partial X} $ represents the weights $ W $ in the linear layer:  $  \delta X = \delta Y \cdot W $        
This avoids explicitly constructing the large Jacobian matrix, as the computation can be performed directly with the weight matrix $ W $ and the gradient $ \delta Y $.

---

### 2. 
**A.** The Jacobian shape calculation can be summarized as follows:
$
\text{Given:} \quad 
\mat{X} \in \mathbb{R}^{N \times \text{in\_features}}, \quad 
\mat{W} \in \mathbb{R}^{\text{out\_features} \times \text{in\_features}}, \quad 
$

I. Total elements in $\mat{Y}$:
$
N \cdot \text{out\_features} = 64 \cdot 512 = 32,768
$

II. Total elements in $\mat{W}$:
$
\text{out\_features} \cdot \text{in\_features} = 512 \cdot 1024 = 524,288
$

III. Shape of the Jacobian:
$
\frac{\partial \mat{Y}}{\partial \mat{W}} \in \mathbb{R}^{(N \cdot \text{out\_features}) \times (\text{out\_features} \cdot \text{in\_features})} = \mathbb{R}^{32,768 \times 524,288}
$

**B.** Yes, the Jacobian is sparse because most elements are zero. 
Non-zero elements exist only for weights $\mathbf{W}[j, :]$ that directly affect the output $\mathbf{Y}[i, j]$, corresponding to the $j$-th feature of $\mathbf{Y}$. Specifically, $ \frac{\partial Y[i, j]}{\partial W[j, n]} = X[i, n] $. All other elements, $\frac{\partial \mathbf{Y}[i, j]}{\partial \mathbf{W}[k, n]} = 0$ for $k \neq j$, are zero, making the Jacobian block-sparse.

**C.** No, we do not need to materialize the Jacobian. Similar to the answer from 1.C., the downstream gradient $ \delta \mathbf{X} $ can be efficiently calculated as $ \delta \mathbf{X} = \delta \mathbf{Y} \cdot \mathbf{W} $. Additionally, the gradient $ \delta \mathbf{W} $ can be directly computed using $ \delta \mathbf{W} = \delta \mathbf{Y}^\top \mathbf{X} $, avoiding explicit construction of the Jacobian.


"""

part1_q2 = r"""
**Your answer:**


Back-propagation is essential for training deep neural networks because it efficiently computes gradients for all parameters, which would be infeasible to calculate manually for large models. It is specifically required for handling the complex interdependencies of layers, ensuring practical optimization in intricate architectures.


"""


# ==============
# Part 2 (Optimization) answers


def part2_overfit_hp():
    wstd, lr, reg = 0, 0, 0
    # TODO: Tweak the hyperparameters until you overfit the small dataset.
    # ====== YOUR CODE: ======

    wstd, lr, reg = 0.1, 0.1, 1e-2

    # ========================
    return dict(wstd=wstd, lr=lr, reg=reg)


def part2_optim_hp():
    wstd, lr_vanilla, lr_momentum, lr_rmsprop, reg, = (
        0,
        0,
        0,
        0,
        0,
    )

    # TODO: Tweak the hyperparameters to get the best results you can.
    # You may want to use different learning rates for each optimizer.
    # ====== YOUR CODE: ======

    wstd = 0.05
    lr_vanilla = 0.02
    lr_momentum = 0.004
    lr_rmsprop = 0.0002
    reg = 0.0015

    # ========================
    return dict(
        wstd=wstd,
        lr_vanilla=lr_vanilla,
        lr_momentum=lr_momentum,
        lr_rmsprop=lr_rmsprop,
        reg=reg,
    )


def part2_dropout_hp():
    wstd, lr, = (
        0,
        0,
    )
    # TODO: Tweak the hyperparameters to get the model to overfit without
    # dropout.
    # ====== YOUR CODE: ======

    wstd = 0.15
    lr = 0.001

    # ========================
    return dict(wstd=wstd, lr=lr)


part2_q1 = r"""
**Your answer:**

1.1.
The graphs comparing the no-dropout and dropout configurations align with our expectations. 

Without dropout, the training accuracy remains more stable across epochs, showing fewer fluctuations compared to the dropout configurations. This is because all neurons are active during training without dropout, leading to stronger and more focused connections within the network. As a result, the model tends to perform well on the training data, resulting in higher training accuracy. 

On the other hand, the introduction of dropout introduces more spikes in the accuracy curves between epochs. Dropout randomly "drops out" a fraction of neurons during each training iteration, encouraging the network to distribute the representation across multiple sets of neurons. This promotes better generalization and reduces overfitting. As a consequence, the model may exhibit lower training accuracy compared to the no-dropout case. 

In terms of test accuracy, the results show a trade-off between the dropout configurations and the no-dropout case. Without dropout, the model achieves higher test accuracy since it has learned strong and specific connections tailored to the training data. However, this can lead to overfitting, where the model fails to generalize well to unseen data.

1.2.
As the dropout rate increases, we observe a decrease in test accuracy but an improvement in generalization. 

For example, comparing a low dropout rate (e.g., 0.4) to no dropout, the test accuracy may slightly decrease, but it helps in reducing overfitting and improving performance on unseen data. Dropout prevents the model from relying too heavily on specific neurons, encouraging the network to learn more robust and generalizable features. 

However, it's important to note that extremely high dropout rates, such as 0.8, can harm both training and testing accuracy. With a dropout rate of 0.8, a significant portion of neurons is disabled during training, severely limiting the model's capacity to learn meaningful patterns from the data. As a result, the model's performance is likely to suffer, yielding poor results for both training and testing.
```python
# A code block
```


"""

part2_q2 = r"""
**Your answer:**


Yes, it is possible. This can occur in certain scenarios due to the behavior of the Cross-Entropy loss function.

The Cross-Entropy loss function penalizes predicted labels $\hat{y}$ that are far from the true labels $y$ in terms of distance. However, accuracy only considers whether the predicted labels are equal to the true labels.

For example, consider some labels where $y_1 = \hat{y}_1$ and $y_2 \ne \hat{y}_2, y_3 \ne \hat{y}_3$, but $y_2$ and $y_3$ are very close to their predicted labels. In an epoch, if $\hat{y}_2$ and $\hat{y}_3$ increase slightly so that $y_2 = \hat{y}_2$ and $y_3 = \hat{y}_3$, while $y_1$ decreases significantly, the following happens:

In this case, all predicted labels remain unchanged except for two that now match their true labels and one that no longer does. As a result, the test accuracy increases.

However, the overall distances between the predicted and true labels increase, leading to a higher loss.
=======
"""

part2_q3 = r"""
**Your answer:**

3.1:
> **Gradient Descent (GD)** is an optimization algorithm used to minimize the loss function by iteratively updating the model's parameters.

> **Backpropagation** is an algorithm used to efficiently calculate the derivatives of the loss function with respect to the parameters using the chain rule.

3.2:
> GD and SGD are both optimization algorithms used in training machine learning models. They differ in how they update the model's parameters:

> In GD, the algorithm considers the entire dataset $X$ in each epoch to decide and perform the update step. In contrast, in SGD, the algorithm samples a subset of the dataset $X$ (of size $BatchSize$) in each epoch and only uses that subset to decide the update step.

> GD is more robust and less sensitive to noisy data compared to SGD because it uses the entire dataset. However, SGD might not reach the minimum (the solution may fluctuate around the optimal point) because it is influenced by individual samples. Nevertheless, SGD takes smaller steps and thus converges faster than GD.

3.3:
> Here are some reasons for preferring SGD:
> * SGD uses only a part of the dataset, making it more efficient and feasible for large datasets where running GD might not be possible.
> * SGD uses different samples in each epoch, which can help it converge better by ignoring some noisy data that might lead to poor updates.
> * SGD converges faster because it takes smaller steps, as explained above.

"""

part2_q4 = r"""
**Your answer:**

4.1.

Reducing the memory complexity for computing the gradient using forward mode Automatic Differentiation (AD) while maintaining O(n) computation cost, we can use checkpointing. we do this by storing only the values required for gradient computation instead of all intermediate results. In the first approach, the algorithm initializes two variables, currentGradient and currentResult, and iterates through the computational graph in a forward pass. At each step, it computes the derivative of the current function and updates the gradient and result accordingly. By storing only the current gradient and result, the memory complexity is reduced to O(1). However, if the intermediate results are not already given, the memory complexity becomes O(n) as we need to store all the intermediate results.

4.2.

Similarly, for backward mode AD, we can use checkpointing to reduce memory complexity while maintaining O(n) computation cost. The second approach initializes two holders, backwardGradient and backwardResult, and performs a forward pass through the computational graph, saving the intermediate function results. Then, in the backward pass, it iterates from the end to the beginning, computing the gradients based on the saved function results. when we store only the necessary function results - the memory complexity is reduced to O(1).

4.3.

they use checkpointing to minimize memory usage during gradient computation. However, it's important to note that these techniques assume a sequential execution of functions and may not be optimal for computational graphs with parallel executions. The memory complexity reduction to O(1) holds under the assumption of a sequential execution. These memory optimization techniques can be generalized for arbitrary computational graphs by employing checkpointing and breaking down the graph into subgraphs. By computing the gradient of each subgraph separately and combining them, we can reduce the memory complexity of the overall gradient computation to O(1). if we cache only the essential values needed for gradient computation, we will be able to handle large and complex computational graphs efficiently.

4.4.

with VGGs and ResNets using said memory optimization techniques offer significant benefits. These architectures often have a large number of parameters and layers, resulting in high memory requirements. By reducing the memory complexity of gradient computation to O(1), we can alleviate the memory burden during training. This advantage becomes crucial, as it enables efficient training on hardware with limited memory resources. Additionally, the reduced memory complexity allows for faster and more scalable training, improving the overall training time of deep architectures.

"""

# ==============


# ==============
# Part 3 (MLP) answers


def part3_arch_hp():
    n_layers = 0  # number of layers (not including output)
    hidden_dims = 0  # number of output dimensions for each hidden layer
    activation = "none"  # activation function to apply after each hidden layer
    out_activation = "none"  # activation function to apply at the output layer
    # TODO: Tweak the MLP architecture hyperparameters.
    # ====== YOUR CODE: ======
    raise NotImplementedError()
    # ========================
    return dict(
        n_layers=n_layers,
        hidden_dims=hidden_dims,
        activation=activation,
        out_activation=out_activation,
    )


def part3_optim_hp():
    import torch.nn
    import torch.nn.functional

    loss_fn = None  # One of the torch.nn losses
    lr, weight_decay, momentum = 0, 0, 0  # Arguments for SGD optimizer
    # TODO:
    #  - Tweak the Optimizer hyperparameters.
    #  - Choose the appropriate loss function for your architecture.
    #    What you returns needs to be a callable, so either an instance of one of the
    #    Loss classes in torch.nn or one of the loss functions from torch.nn.functional.
    # ====== YOUR CODE: ======
    raise NotImplementedError()
    # ========================
    return dict(lr=lr, weight_decay=weight_decay, momentum=momentum, loss_fn=loss_fn)


part3_q1 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""

part3_q2 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""

part3_q3 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""


part3_q4 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""
# ==============
# Part 4 (CNN) answers


def part4_optim_hp():
    import torch.nn
    import torch.nn.functional

    loss_fn = None  # One of the torch.nn losses
    lr, weight_decay, momentum = 0, 0, 0  # Arguments for SGD optimizer
    # TODO:
    #  - Tweak the Optimizer hyperparameters.
    #  - Choose the appropriate loss function for your architecture.
    #    What you returns needs to be a callable, so either an instance of one of the
    #    Loss classes in torch.nn or one of the loss functions from torch.nn.functional.
    # ====== YOUR CODE: ======
    raise NotImplementedError()
    # ========================
    return dict(lr=lr, weight_decay=weight_decay, momentum=momentum, loss_fn=loss_fn)


part4_q1 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""

# ==============

# ==============
# Part 5 (CNN Experiments) answers


part5_q1 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""

part5_q2 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""

part5_q3 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""

part5_q4 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""


# ==============

# ==============
# Part 6 (YOLO) answers


part6_q1 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""


part6_q2 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""


part6_q3 = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""

part6_bonus = r"""
**Your answer:**


Write your answer using **markdown** and $\LaTeX$:
```python
# A code block
a = 2
```
An equation: $e^{i\pi} -1 = 0$

"""